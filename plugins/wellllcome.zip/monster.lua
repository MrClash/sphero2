do

function run(msg, matches)
  return [[
ورژن ربات 1
بات انتی اسپمر و هوشمند تلگرام
سازنده و صاحب ربات
@Mr_Vigeo 
درخواست گروه با قیمت مناسب
@pvmrvigeobot
  ]]

  end
return {
  description = "shows sudoers", 
  usage = "!sudoers : return sudousers",
  patterns = {
    "^[Ss]hadow$",

  },
  run = run
}
end
