do

function run(msg, matches)
  return [[
نرخ گروه های سایه
لیست قیمت ها:
http://s7.picofile.com/file/8239656634/Untitled.png
برای خرید
@mr_vigeo (انهایی که ریپورت نیستند)
@pvmrvigeobot (انهایی که ریپورت هستند)
  ]]

  end
return {
  description = "shows sudoers", 
  usage = "!sudoers : return sudousers",
  patterns = {
    "^[Nn]erkh$",

  },
  run = run
}
end
